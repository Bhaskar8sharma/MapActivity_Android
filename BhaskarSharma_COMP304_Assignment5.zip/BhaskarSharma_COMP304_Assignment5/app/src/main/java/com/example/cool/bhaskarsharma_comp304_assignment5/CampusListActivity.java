package com.example.cool.bhaskarsharma_comp304_assignment5;

import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class CampusListActivity extends AppCompatActivity {
    ListView campusListV;
    ArrayAdapter adapter;
    List<Address> geoLoc;
    Context thisOne;
    List campusLocation = new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_campus_list);

        String selectedCollege = getIntent().getStringExtra("collegeName");
        List campusList = new ArrayList();

        thisOne = this;


        switch (selectedCollege)
        {
            case "Centennial College":
                campusList = Arrays.asList(getResources().getStringArray(R.array.CentennialCampus));
                campusLocation = Arrays.asList(getResources().getStringArray(R.array.CentennialLocations));
                break;
            case "Cambrian College":
                campusList = Arrays.asList(getResources().getStringArray(R.array.CambrianCampus));
                campusLocation = Arrays.asList(getResources().getStringArray(R.array.CambrianLocations));
                break;
            case "Conestoga College":
                campusList = Arrays.asList(getResources().getStringArray(R.array.ConestogaCampus));
                campusLocation = Arrays.asList(getResources().getStringArray(R.array.ConestogaLocations));
                break;
            case "Humber College":
                campusList = Arrays.asList(getResources().getStringArray(R.array.HumberCampus));
                campusLocation = Arrays.asList(getResources().getStringArray(R.array.HumberLocations));
                break;
            case "George Brown College":
                campusList = Arrays.asList(getResources().getStringArray(R.array.GeorgeBrownCampus));
                campusLocation = Arrays.asList(getResources().getStringArray(R.array.GeorgeBrownLocations));
                break;
        }

        ((TextView) findViewById(R.id.collegeSelect)).setText("College: " + selectedCollege);

        campusListV = findViewById(R.id.campusList);
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, campusList);
        campusListV.setAdapter(adapter);

        campusListV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                Intent in;
                String set = (String) campusListV.getItemAtPosition(position);
                set += " ,Toronto, ON";

                in = new Intent(CampusListActivity.this, MapsActivity.class);
                String x = (String) campusLocation.get(position);
                String[] coordinates = x.split(",");

                try
                {
                    geoLoc = new Geocoder(thisOne, Locale.getDefault()).getFromLocationName(set, 1);
                    if(geoLoc.isEmpty())
                    {
                        in.putExtra("Latitude", Double.parseDouble(coordinates[0]));
                        in.putExtra("Longitude", Double.parseDouble(coordinates[1]));
                    }
                    else
                    {
                        in.putExtra("Latitude", geoLoc.get(0).getLatitude());
                        in.putExtra("Longitude", geoLoc.get(0).getLongitude());
                    }
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }

                in.putExtra("st", set);
                startActivity(in);


            }
        });
    }
}
